package data.scripts;

import java.awt.Color;
import java.util.List;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.impl.campaign.econ.AbandonedStation;

import com.fs.starfarer.api.campaign.CustomCampaignEntityAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.PlanetSpecAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.EconomyAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;

import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.combat.entities.terrain.Planet;

import exerelin.campaign.SectorManager;
import com.fs.starfarer.api.util.Misc;



import static com.fs.starfarer.api.Global.getSettings;

public class dl_ModPlugin extends BaseModPlugin {
	@Override
	public void onNewGame() {
		
		//NEXERELIN COMPATIBILITY CHECK, IF NOT NEX OR CORVUSMODE(NEX), PROCEED
        boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");
        if (!haveNexerelin || SectorManager.getCorvusMode()) {
            generate_dalcass_system();
        }
		
		//generate_dalcass_system(); //DECOMMENT THIS LINE AND COMMENT THE BOOLEAN AND IF AS WELL AS 'exerelin' IMPORT TO REMOVE ALL DEPENDENCIES
	}
	
/**

	CREATE DALCASS SYSTEM WITH DALCASS AS PRIMARY STAR, CREATE SECOND SUN: BELISSARIUS

**/
	private void generate_dalcass_system() {
		StarSystemAPI system_dalcass = Global.getSector().createStarSystem("Dalcass");//CREATES DALCASS SYSTEM
		/**
		CREATE DALCASS STAR AND CUSTOMIZE
		**/
		system_dalcass.setBackgroundTextureFilename("graphics/backgrounds/Dalcass.png");// CUSTOM BACKDROP		
		PlanetAPI star_dalcass = system_dalcass.initStar(//CREATE DALCASSIUS
		"dl_star_dalcass", 
		"star_orange", 
		500, //SIZE OF STAR
		-4000,  //X-POSITION IN SECTOR
		-25000, //Y-POSITION IN SECTOR
		250);//HOW FAR FROM STAR SHOULD THE CORONA EXTEND
		star_dalcass.setCustomDescriptionId("dl_star_dalcass");//USE CUSTOM DESC FOR DALCASSIUS STAR
		//system_dalcass.setLightColor(new Color(212, 175, 55));//Brown-87,44,0,255 DimGold-181,150,119,255 Metalgold-212,175,55,255
		system_dalcass.setLightColor(new Color(181, 150, 119));//CUSTOM SYSTEM COLOUR
		//DALCASSIUS STAR SETUP CUSTOM IMAGES
		PlanetSpecAPI dalcassius_specs = star_dalcass.getSpec();//RETRIEVES SPECS OF 'star_dalcass'
		dalcassius_specs.setTexture("graphics/stars/Dalcass.png");
		dalcassius_specs.setCoronaColor(new Color(212,175,55));
		star_dalcass.applySpecChanges();
		
		/**
		CREATE BELISSARIUS STAR AND CUSTOMIZE
		**/
		PlanetAPI star_belissarius = system_dalcass.addPlanet(
		
			"dl_star_belissarius", //ID OF PLANET
			star_dalcass, //WHAT IT ORBITS (TYPE 'SectorEntityToken'). INSTEAD OF 'star_dalcass' OTHER PLANETS OR 'SectorEntityToken's CAN BE USED
			"Belissarius", //PLANET NAME
			"star_yellow", //PLANET TYPE
			0, //STARTING ANGULAR POSITION AROUND ITS ORBIT POINT ('star_dalcass')
			700, //PLANET RADIUS
			1500, //DISTANCE FROM ORBIT POINT ('star_dalcass')
			120 //ORBITAL PERIOD IN DAYS (SPEED OF PLANET IN ITS ORBIT)
		
		);
		star_belissarius.setCustomDescriptionId("dl_star_belissarius");//USE CUSTOM DESC FOR BELISSARIUS STARPLANET
		
		/**
		DALCASS SYSTEM ASTEROID BELT
		**/
        system_dalcass.addAsteroidBelt(
			star_dalcass, //WHAT IT ORBITS
			300, //NUMBER OF ASTEROIDS
			2700f, //ORBIT RADIUS
			225f, //WIDTH
			180, //MIN SPEED
			360, //MAX SPEED
			Terrain.ASTEROID_BELT, "" //TYPE AND OPTIONAL NAME 
			);


		
/**
	CREATE SYSTEM PLANETS & THEIR MARKETS: DALCASSIA, ARMAGEDDYN, INFYRNO
**/
		/**GENERATE DALCASSIA**/
		PlanetAPI planet_dalcassia = system_dalcass.addPlanet(
			"dl_planet_dalcassia", //ID OF PLANET
			star_dalcass, //WHAT IT ORBITS
			"Dalcassia", //PLANET NAME
			"terran", //PLANET TYPE
			360, //STARTING ANGULAR POSITION AROUND ITS ORBIT POINT
			120, //PLANET RADIUS
			5000, //DISTANCE FROM ORBIT POINT ('star_dalcass')
			120);//ORBITAL PERIOD IN DAYS (SPEED OF PLANET IN ITS ORBIT)
		planet_dalcassia.setCustomDescriptionId("dl_planet_dalcassia");//SET CUSTOM DESC.
		PlanetSpecAPI dalcassia_specs = planet_dalcassia.getSpec();//SET CUSTOM IMAGE
		dalcassia_specs.setTexture("graphics/planets/Dalcassia.png");
		planet_dalcassia.applySpecChanges();
		planet_dalcassia.setFaction("dalcassian");//SET FACTION OWNERSHIP OF PLANET.
		
		/**GENERATE DALCASSIA MARKET**/
		MarketAPI market_dalcassia = Global.getFactory().createMarket(
			"dl_market_dalcassia", //MARKET ID
			planet_dalcassia.getName(), //MARKET DISPLAY NAME, ex: planet_dalcassia.getName() SETS TO PLANET NAME.
			6 //MARKET SIZE
		);
		
		planet_dalcassia.setMarket(market_dalcassia);
		market_dalcassia.setPrimaryEntity(planet_dalcassia);
		market_dalcassia.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
		market_dalcassia.getTariff().modifyFlat("generator", 0.3f);

		/**DALCASSIA SURFACE CONDITIONS**/
		market_dalcassia.setPlanetConditionMarketOnly(false);
		market_dalcassia.addCondition(Conditions.HABITABLE);
		market_dalcassia.addCondition(Conditions.FARMLAND_RICH);
		market_dalcassia.addCondition(Conditions.ORGANICS_ABUNDANT);
		market_dalcassia.addCondition(Conditions.ORE_RICH);
		market_dalcassia.addCondition(Conditions.POPULATION_6);//MATCH MARKET SIZE
		market_dalcassia.setFactionId("dalcassian");//SET MARKET OWNERSHIP
		
		/**DALCASSIA MARKET INDUSTRIES**/
		market_dalcassia.addIndustry(Industries.POPULATION);
		market_dalcassia.addIndustry(Industries.MEGAPORT);
		market_dalcassia.addIndustry(Industries.STARFORTRESS_HIGH);
		market_dalcassia.addIndustry(Industries.HEAVYBATTERIES);
		//market_dalcassia.addIndustry(Industries.PATROLHQ);		
		market_dalcassia.addIndustry(Industries.WAYSTATION);			
		market_dalcassia.addIndustry(Industries.FARMING);
		market_dalcassia.addIndustry(Industries.MINING);
		//market_dalcassia.addIndustry(Industries.COMMERCE);
		market_dalcassia.addIndustry(Industries.HIGHCOMMAND);			
		market_dalcassia.addIndustry(Industries.LIGHTINDUSTRY);
		
		
		/**DALCASSIA MARKET SUBMARKETS**/
		market_dalcassia.addSubmarket(Submarkets.SUBMARKET_STORAGE);
		market_dalcassia.addSubmarket(Submarkets.SUBMARKET_BLACK);
		market_dalcassia.addSubmarket(Submarkets.SUBMARKET_OPEN);
		
		/**ADD DALCASSIA TO SECTOR ECONOMY**/
		EconomyAPI globalEconomy = Global.getSector().getEconomy();		
		globalEconomy.addMarket(
			market_dalcassia,
			false 
		);
		
		
/*****************************************************************************************************/
		/**GENERATE ARMAGEDDYN**/
		PlanetAPI planet_armageddyn = system_dalcass.addPlanet(
			"dl_planet_armageddyn", //ID OF PLANET
			planet_dalcassia, //WHAT IT ORBITS
			"Armageddyn", //PLANET NAME
			"rocky_metallic", //PLANET TYPE
			240, //STARTING ANGULAR POSITION AROUND ITS ORBIT POINT
			100, //PLANET RADIUS
			700, //DISTANCE FROM ORBIT POINT ('planet_dalcassia')
			120);//ORBITAL PERIOD IN DAYS (SPEED OF PLANET IN ITS ORBIT)
		planet_armageddyn.setCustomDescriptionId("dl_planet_armageddyn");//SET CUSTOM DESC.
		PlanetSpecAPI armageddyn_specs = planet_armageddyn.getSpec();//SET CUSTOM IMAGE
		armageddyn_specs.setTexture("graphics/planets/Armageddyn.png");
		planet_armageddyn.applySpecChanges();
		planet_armageddyn.setFaction("dalcassian");//SET FACTION OWNERSHIP OF PLANET.
		
		/**GENERATE ARMAGEDDYN MARKET**/
		MarketAPI market_armageddyn = Global.getFactory().createMarket(
			"dl_market_armageddyn", //MARKET ID
			planet_armageddyn.getName(), //MARKET DISPLAY NAME, ex: planet_dalcassia.getName() SETS TO PLANET NAME.
			5 //MARKET SIZE
		);
		
		planet_armageddyn.setMarket(market_armageddyn);
		market_armageddyn.setPrimaryEntity(planet_armageddyn);
		market_armageddyn.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
		market_armageddyn.getTariff().modifyFlat("generator", 0.3f);

		/**ARMAGEDDYN SURFACE CONDITIONS**/
		market_armageddyn.setPlanetConditionMarketOnly(false);
		market_armageddyn.addCondition(Conditions.NO_ATMOSPHERE);
		market_armageddyn.addCondition(Conditions.POPULATION_5);//MATCH MARKET SIZE
		market_armageddyn.setFactionId("dalcassian");//SET MARKET OWNERSHIP
		
		/**ARMAGEDDYN MARKET INDUSTRIES**/
		market_armageddyn.addIndustry(Industries.POPULATION);
		market_armageddyn.addIndustry(Industries.MEGAPORT);
		market_armageddyn.addIndustry(Industries.BATTLESTATION_HIGH);
		market_armageddyn.addIndustry(Industries.HEAVYBATTERIES);
		market_armageddyn.addIndustry(Industries.PATROLHQ);		
		market_armageddyn.addIndustry(Industries.WAYSTATION);
		market_armageddyn.addIndustry(Industries.ORBITALWORKS);
		market_armageddyn.addIndustry(Industries.REFINING);
		market_armageddyn.addIndustry(Industries.FUELPROD);				

		/**ARMAGEDDYN MARKET SUBMARKETS**/
		market_armageddyn.addSubmarket(Submarkets.SUBMARKET_STORAGE);
		market_armageddyn.addSubmarket(Submarkets.SUBMARKET_BLACK);
		market_armageddyn.addSubmarket(Submarkets.SUBMARKET_OPEN);
		
		/**ADD ARMAGEDDYN TO SECTOR ECONOMY**/

		globalEconomy.addMarket(
			market_armageddyn,
			false 
		);
		
/*****************************************************************************************************/
		/**GENERATE INFYRNO**/
		PlanetAPI planet_infyrno = system_dalcass.addPlanet(
			"dl_planet_infyrno", //ID OF PLANET
			star_dalcass, //WHAT IT ORBITS
			"Infyrno", //PLANET NAME
			"barren_castiron", //PLANET TYPE
			90, //STARTING ANGULAR POSITION AROUND ITS ORBIT POINT
			140, //PLANET RADIUS
			3500, //DISTANCE FROM ORBIT POINT ('planet_dalcassia')
			120);//ORBITAL PERIOD IN DAYS (SPEED OF PLANET IN ITS ORBIT)
		planet_infyrno.setCustomDescriptionId("dl_planet_infyrno");//SET CUSTOM DESC.
		PlanetSpecAPI infyrno_specs = planet_infyrno.getSpec();//SET CUSTOM IMAGE
		infyrno_specs.setTexture("graphics/planets/Infyrno.png");
		planet_infyrno.applySpecChanges();
		planet_infyrno.setFaction("dalcassian");//SET FACTION OWNERSHIP OF PLANET.
		
		/**GENERATE INFYRNO MARKET**/
		MarketAPI market_infyrno = Global.getFactory().createMarket(
			"dl_market_infyrno", //MARKET ID
			planet_infyrno.getName(), //MARKET DISPLAY NAME, ex: planet_dalcassia.getName() SETS TO PLANET NAME.
			4 //MARKET SIZE
		);
		
		planet_infyrno.setMarket(market_infyrno);
		market_infyrno.setPrimaryEntity(planet_infyrno);
		market_infyrno.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
		market_infyrno.getTariff().modifyFlat("generator", 0.3f);

		/**INFYRNO SURFACE CONDITIONS**/
		market_infyrno.setPlanetConditionMarketOnly(false);
		market_infyrno.addCondition(Conditions.VERY_HOT);
		market_infyrno.addCondition(Conditions.RUINS_VAST);
		market_infyrno.addCondition(Conditions.ORE_RICH);
		market_infyrno.addCondition(Conditions.RARE_ORE_RICH);
		market_infyrno.addCondition(Conditions.POPULATION_4);//MATCH MARKET SIZE
		market_infyrno.setFactionId("dalcassian");//SET MARKET OWNERSHIP
		
		/**INFYRNO MARKET INDUSTRIES**/
		market_infyrno.addIndustry(Industries.POPULATION);
		market_infyrno.addIndustry(Industries.MEGAPORT);
		market_infyrno.addIndustry(Industries.STARFORTRESS_HIGH);
		market_infyrno.addIndustry(Industries.HEAVYBATTERIES);		
		market_infyrno.addIndustry(Industries.WAYSTATION);	
		market_infyrno.addIndustry(Industries.MINING);
		market_infyrno.addIndustry(Industries.HIGHCOMMAND);		

		/**INFYRNO MARKET SUBMARKETS**/
		market_infyrno.addSubmarket(Submarkets.SUBMARKET_STORAGE);
		market_infyrno.addSubmarket(Submarkets.SUBMARKET_BLACK);
		market_infyrno.addSubmarket(Submarkets.SUBMARKET_OPEN);
		
		/**ADD INFYRNO TO SECTOR ECONOMY**/

		globalEconomy.addMarket(
			market_infyrno,
			false 
		);

/**
	CREATE MISC SYSTEM CELESTIAL BODIES: JUMP POINTS, DALCASS GATE, BUOY, RELAY, ARRAY, 
**/

		/**DALCASS JUMPPOINT**/
		JumpPointAPI dalcass_jp = Global.getFactory().createJumpPoint("dalcass_jump_point", "Fringe Jump Point");
		dalcass_jp.setCircularOrbit(
			system_dalcass.getEntityById("dl_planet_infyrno"), //WHAT IT ORBITS
			0, ////STARTING ANGULAR POSITION AROUND ITS ORBIT POINT
			600, //DISTANCE FROM ORBIT POINT ('planet_infyrno')
			90);  //ORBITAL PERIOD IN DAYS (SPEED OF BODY IN ITS ORBIT)
		dalcass_jp.setStandardWormholeToHyperspaceVisual();
		system_dalcass.addEntity(dalcass_jp);
		
		/**DALCASS GATE**/
		SectorEntityToken dalcass_gate = system_dalcass.addCustomEntity("dalcass_gate", "Dalcass Gate", "inactive_gate", null);
		dalcass_gate.setCircularOrbit(
			star_belissarius, //WHAT IT ORBITS
			0, ////STARTING ANGULAR POSITION AROUND ITS ORBIT POINT
			2200, //DISTANCE FROM ORBIT POINT ('star_belissarius')
			180);  //ORBITAL PERIOD IN DAYS (SPEED OF BODY IN ITS ORBIT)

		/**DALCASS BUOY**/
		SectorEntityToken dalcass_buoy = system_dalcass.addCustomEntity("dalcass_buoy", "Dalcass Buoy", "nav_buoy", "neutral");
		dalcass_buoy.setCircularOrbitPointingDown(
			planet_dalcassia, //WHAT IT ORBITS
			60, ////STARTING ANGULAR POSITION AROUND ITS ORBIT POINT
			400, //DISTANCE FROM ORBIT POINT ('planet_dalcassia')
			45); //ORBITAL PERIOD IN DAYS (SPEED OF BODY IN ITS ORBIT)

		/**DALCASS RELAY**/
		SectorEntityToken dalcass_relay = system_dalcass.addCustomEntity("dalcass_relay", "Dalcass Relay", "comm_relay", "neutral");
		dalcass_relay.setCircularOrbitPointingDown(
			planet_armageddyn, //WHAT IT ORBITS
			180, ////STARTING ANGULAR POSITION AROUND ITS ORBIT POINT
			400, //DISTANCE FROM ORBIT POINT ('planet_dalcassia')
			45); //ORBITAL PERIOD IN DAYS (SPEED OF BODY IN ITS ORBIT)

		/**DALCASS ARRAY**/
		SectorEntityToken dalcass_array = system_dalcass.addCustomEntity("dalcass_array", "Dalcass Array", "sensor_array", "neutral");
		dalcass_array.setCircularOrbitPointingDown(
			planet_infyrno, //WHAT IT ORBITS
			300, ////STARTING ANGULAR POSITION AROUND ITS ORBIT POINT
			400, //DISTANCE FROM ORBIT POINT ('planet_dalcassia')
			45); //ORBITAL PERIOD IN DAYS (SPEED OF BODY IN ITS ORBIT)

		
		system_dalcass.autogenerateHyperspaceJumpPoints(false, false);
		

	}


	
}