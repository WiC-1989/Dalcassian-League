
 ___________  __    __    _______      ________       __      ___       ______        __        ________  ________  __          __      _____  ___      
("     _   ")/" |  | "\  /"     "|    |"      "\     /""\    |"  |     /" _  "\      /""\      /"       )/"       )|" \        /""\    (\"   \|"  \     
 )__/  \\__/(:  (__)  :)(: ______)    (.  ___  :)   /    \   ||  |    (: ( \___)    /    \    (:   \___/(:   \___/ ||  |      /    \   |.\\   \    |    
    \\_ /    \/      \/  \/    |      |: \   ) ||  /' /\  \  |:  |     \/ \        /' /\  \    \___  \   \___  \   |:  |     /' /\  \  |: \.   \\  |    
    |.  |    //  __  \\  // ___)_     (| (___\ || //  __'  \  \  |___  //  \ _    //  __'  \    __/  \\   __/  \\  |.  |    //  __'  \ |.  \    \. |    
    \:  |   (:  (  )  :)(:      "|    |:       :)/   /  \\  \( \_|:  \(:   _) \  /   /  \\  \  /" \   :) /" \   :) /\  |\  /   /  \\  \|    \    \ |    
     \__|    \__|  |__/  \_______)    (________/(___/    \___)\_______)\_______)(___/    \___)(_______/ (_______/ (__\_|_)(___/    \___)\___|\____\)    
 ___       _______       __       _______  ____  ____   _______         ______    _______                                                               
|"  |     /"     "|     /""\     /" _   "|("  _||_ " | /"     "|       /    " \  /"     "|                                                              
||  |    (: ______)    /    \   (: ( \___)|   (  ) : |(: ______)      // ____  \(: ______)                                                              
|:  |     \/    |     /' /\  \   \/ \     (:  |  | . ) \/    |       /  /    ) :)\/    |                                                                
 \  |___  // ___)_   //  __'  \  //  \ ___ \\ \__/ //  // ___)_     (: (____/ // // ___)                                                                
( \_|:  \(:      "| /   /  \\  \(:   _(  _|/\\ __ //\ (:      "|     \        / (:  (                                                                   
 \_______)\_______)(___/    \___)\_______)(__________) \_______)      \"_____/   \__/                                                                   
      __        ________  ________   ______    ______                 _______   ___            __      _____  ___    _______  ___________  ________     
     /""\      /"       )/"       ) /    " \  /" _  "\               |   __ "\ |"  |          /""\    (\"   \|"  \  /"     "|("     _   ")/"       )    
    /    \    (:   \___/(:   \___/ // ____  \(: ( \___)              (. |__) :)||  |         /    \   |.\\   \    |(: ______) )__/  \\__/(:   \___/     
   /' /\  \    \___  \   \___  \  /  /    ) :)\/ \                   |:  ____/ |:  |        /' /\  \  |: \.   \\  | \/    |      \\_ /    \___  \       
  //  __'  \    __/  \\   __/  \\(: (____/ // //  \ _    _____       (|  /      \  |___    //  __'  \ |.  \    \. | // ___)_     |.  |     __/  \\      
 /   /  \\  \  /" \   :) /" \   :)\        / (:   _) \  ))_  ")     /|__/ \    ( \_|:  \  /   /  \\  \|    \    \ |(:      "|    \:  |    /" \   :)     
(___/    \___)(_______/ (_______/  \"_____/   \_______)(_____(     (_______)    \_______)(___/    \___)\___|\____\) \_______)     \__|   (_______/  v0.00    
                                                                                                                                                        

v0.01 - Bugfix
- Add SYSTEM hints and no_drop, no_drop_salvage to HERC built in weapons (re: arms)
- Add asteroid belt to Dalcass system
- Adjust Dalcassia and Armageddyn orbit distance
- Adjust Dalcassia industries
- Added Dalcassian faction to Prism whitelist
- Added Dalcassian specific portraits to dalcassian.faction and player.faction

v0.00 - Initial Release
- Added Dalcass system @  -4000 & -25000
- Added Dalcassia, Armageddyn and Infyrno to Dalcass System
- Added v0.00 Felis, Felis_w, Arise, Torus and Stouthawk HERCULANs
- Added v0.00 Ajax, Mandela and Weekend Class ships
- Added v0.00 Gilbert, Schlag, Lanze and Zupfen standard weapons
- Added v0.00 Heavenbolt Medium and Large Missiles
- Added v0.00 Saracusa S, M, L and Plasma Driver S, M, L Missiles
- Added support for Nexerelin (0.10.5b at time of creation) Random and Standard Sector generation




  ________  _______    _______   ______    __          __      ___                                      
 /"       )|   __ "\  /"     "| /" _  "\  |" \        /""\    |"  |                                     
(:   \___/ (. |__) :)(: ______)(: ( \___) ||  |      /    \   ||  |                                     
 \___  \   |:  ____/  \/    |   \/ \      |:  |     /' /\  \  |:  |                                     
  __/  \\  (|  /      // ___)_  //  \ _   |.  |    //  __'  \  \  |___                                  
 /" \   :)/|__/ \    (:      "|(:   _) \  /\  |\  /   /  \\  \( \_|:  \                                 
(_______/(_______)    \_______) \_______)(__\_|_)(___/    \___)\_______)                                
 ___________  __    __       __      _____  ___   __   ___   ________      ___________  ______    ____  
("     _   ")/" |  | "\     /""\    (\"   \|"  \ |/"| /  ") /"       )    ("     _   ")/    " \  ))_ ") 
 )__/  \\__/(:  (__)  :)   /    \   |.\\   \    |(: |/   / (:   \___/      )__/  \\__/// ____  \(____(  
    \\_ /    \/      \/   /' /\  \  |: \.   \\  ||    __/   \___  \           \\_ /  /  /    ) :)_____  
    |.  |    //  __  \\  //  __'  \ |.  \    \. |(// _  \    __/  \\          |.  | (: (____/ // ))_ ") 
    \:  |   (:  (  )  :)/   /  \\  \|    \    \ ||: | \  \  /" \   :)         \:  |  \        / (____(  
     \__|    \__|  |__/(___/    \___)\___|\____\)(__|  \__)(_______/           \__|   \"_____/          
                                                                                                        

- https://patorjk.com/ for ASCII art generator
- https://www.spriters-resource.com/ for the sprites used for the kitbashed graphics
- https://www.reddit.com/user/Four_Murasame/ for the misc. gundam sound effects
- https://convertio.co/wav-ogg/ for conversion of .wavs to .oggs
- Lukas04, Harmful Mechanic and others on the forums and discord for putting up with my stupid questions - special thanks to Vayra and Wadestar for the tutorials that helped me stumble blindly to create something useable.



